Mystery Agent (1.0)

This agent...  No, that would spoil the fun :)

Credits
-------
Concept & CAOS: Emmental
Sprites:        Sentinal

Emmental
https://github.com/chiizujin/edsa
