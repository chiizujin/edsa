Gadget Shelf (1.0)

A shelf on which to put gadgets to keep them out of reach of mischievous hands.

Usage
-----
Note that, because the shelf is actually much taller than it appears to be, it
can't be placed close to the top of a room. This is to allow space for the C3
Pulsed Switch to fit on the shelf.

Emmental
https://github.com/chiizujin/edsa
