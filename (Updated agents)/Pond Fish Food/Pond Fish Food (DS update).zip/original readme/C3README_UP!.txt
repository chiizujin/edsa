Pond Fish Food
Creature 3 cob: 

This small cube will keep the stickelback trouts in the pond well fed and vigorous.
Just get one of them from the Creator and toss it into the pond,the fish will then snack on it at their leisure. Never needs replacing!:)

These will only work with Creatures 3 and not Creatures 1 or Creatures 2.

To install:

Place the .agent file into your /Creatures 3/My Agents directory.
Place the .c16 file into your /Creatures 3/Images directory.

And use the Creator machine inside of C3 to load the agent into your world.


Spirit

Creatures Shack
http://members.xoom.com/tsi333/nindex.html
