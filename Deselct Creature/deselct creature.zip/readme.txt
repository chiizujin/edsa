Deselect Creature (1.0)

Adds a button that can be used to deselect the current creature and stop camera
tracking.

Alternatively, you can use CTRL+SHIFT+N to do the same thing.

Notes
----
- The deselect button is only visible when a creature is selected, so if you
  inject the agent and nothing appears to happen then you probably don't have a
  creature selected.
- The game will occasionally begin camera-tracking a creature again. I'm not
  sure what this is based on.

Emmental
https://github.com/chiizujin/edsa
