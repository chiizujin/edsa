Description Viewer (1.0)
------------------------

If a creature's description is very long then it cannot all be seen in the
creature history panel. This can be inconvenient when using the Ancestry Tracker
(from Verm's Various Agents Pack) at higher generations.

This agent adds a button beside the description box that can be used to view the
full description in a paged panel.

The panel can be left open and will update as you tab through creatures, as long
as the history panel is still open.

Thanks
------
Thanks to Mea and goodmode for testing.
