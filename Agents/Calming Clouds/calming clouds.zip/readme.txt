Calming Clouds (1.0)

Mysterious white clouds occasionally drift around, calming down any
overly-frisky Norns.

Notes
-----
- This agent is intended to be injected and removed as required.
- While it will drastically reduce the number of pregnancies, it is not
  foolproof and may occasionally allow a one to happen.

Emmental
https://github.com/chiizujin/edsa
