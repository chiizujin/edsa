Noisy Maracas (1.1)

These maracas are fun for creatures to play with, but we all know how
irritating they can be, and other creatures feel the same way...

Version history
---------------
1.1
- Fixed an error occurring when putting the maracas in the inventory.
  This could also happen occasionally at other times.

Emmental
https://github.com/chiizujin/edsa
