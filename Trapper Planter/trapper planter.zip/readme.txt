Trapper Planter (1.0)

This useful tool allows you to plant extra trappers almost anywhere in
your world to help get rid of pesky bugs.

Credits
-------
Concept & sprites: Random
CAOS:              Emmental

Random
http://members.home.net/dockingstation/
Emmental
https://github.com/chiizujin/edsa
