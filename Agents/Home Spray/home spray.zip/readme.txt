Home Spray (1.2)

This spray releases clouds into the air that help homesick Norns feel better.

Credits
-------
Concept & sprites: Sentinal
CAOS:              Emmental

Version history
---------------
1.2
- The agent can now be injected using the C3 creator machine without
  causing errors (or killing the machine if auto-kill is enabled).
1.1
- Fixed the .catalogue file not being extracted from the .agents file.
  This meant there would be no agent help available in the game.

Emmental
https://github.com/chiizujin/edsa
