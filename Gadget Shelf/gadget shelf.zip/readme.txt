Gadget Shelf (1.1)

A shelf on which to put gadgets to keep them out of reach of mischievous hands.

Usage
-----
Note that, because the shelf is actually much taller than it appears to be, it
can't be placed close to the top of a room. This is to allow space for the C3
Pulsed Switch to fit on the shelf.

Installation (only necessary if you have used version 1.0)
----------------------------------------------------------
Do the following before installing the new "gadget shelf.agents":
  1. Remove Gadget Shelf from any of your worlds.
  2. Quit the game.
  3. Delete the file "gadget shelf.catalogue" from the Catalogue folder.

Version history
---------------
1.1
- Changed the agent classifier to avoid a clash.

Emmental
https://github.com/chiizujin/edsa
