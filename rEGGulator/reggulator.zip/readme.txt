rEGGulator (1.0)

The rEGGulator will attempt to maintain a desired number of Norn eggs. If there
are too few then Norns will be encouraged to breed. Too many and Norns are
discouraged from breeding.

The desired minimum and maximum numbers of eggs can be set by clicking the
number, entering a new value and pressing enter.

The rEGGulator can be turned on and off with the green button. This button
blinks every five seconds as the rEGGulator works."

Notes
-----
It's a minor point of note, but Norns are discouraged from breeding when the
number of eggs is *at* the maximum limit since we do not want to go over that
number.

Installation
-----------
Due to the way the Agent Injector/Creator sort agents in their lists, the
rEGGulator will appear near the end of the list.

Emmental
https://github.com/chiizujin/edsa
