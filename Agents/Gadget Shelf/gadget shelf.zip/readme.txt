Gadget Shelf (1.2)

A shelf on which to put gadgets to keep them out of reach of mischievous hands.

Upgrading from an earlier version
---------------------------------
Do the following before installing the new "gadget shelf.agents":
  1. Remove Gadget Shelf from any of your worlds.
  2. Quit the game.
  3. Delete the file "gadget shelf.c16" from the Images folder.
  4. Delete the file "gadget shelf.catalogue" from the Catalogue folder. (Only
     necessary if your previous version was 1.0).

Version history
---------------
1.2
- Increased the height of the cabin and Changed the way the cabin works so that
  the shelf can be placed close to the top of a room. Note that agents may drop
  onto the shelf from above if the top of it overlaps onto another "floor" in
  the metaroom.
1.1
- Changed the agent classifier to avoid a clash.

Emmental
https://github.com/chiizujin/edsa
