Camera Fixer (1.0)

Use this to keep your Docking Station cameras in place.

Clicking this camera will lock all your Docking Station cameras in
their current positions so that they cannot be moved by creatures or
the hand.  They will even be forced back to where you left them when
the world loads and they move.

When the Camera Fixer is red the cameras are locked.  When green the
cameras behave as normal.

Emmental
https://github.com/chiizujin/edsa
