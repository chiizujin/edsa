Egg Layer Remover (1.0)

When injected, this agent removes the Ettin and Grendel egg layers
from the current world.

This is useful for people who would like to use the C3-in-DS meta-room
agents but do not want Ettins or Grendels in their world.

Please use this with care as they cannot be re-installed with this
agent.

Emmental
https://github.com/chiizujin/edsa
