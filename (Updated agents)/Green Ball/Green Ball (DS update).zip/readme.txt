Green Ball - Docking Station Update (1.1)

This is an update of the Green Ball by Uttar and Tim to enable it to be fully
compatible with undocked Docking Station worlds.

The agent will be injected in the Comms Room in undocked DS worlds and in its
original location in C3 and docked DS worlds.

Distribution note
-----------------
I have attempted to contact both authors for distribution permission but the
email addresses are no longer valid and the web sites no longer exist. If either
author would like me to remove this agent from my site then please contact me
(Chiizujin on Discord).

Credits
-------
Original agent:          Uttar and Tim
DS compatibility update: Emmental

Version history
---------------
1.1
- Prevented perpetual spinning.
- Updated PRAY uninstall script with missing script removals.

Emmental
https://github.com/chiizujin/edsa
