Towel (1.0)

A tribute to Douglas Adams.

Emmental
http://www.towelday.org
https://github.com/chiizujin/edsa
