Interporter - Update

This is an update of Interporter by Mugendai to fix the teleport sound being cut
off when a creature teleports. The sound is now emitted from both teleporters as
opposed to being attached to the creature.

It also includes the stim fix script that was released later. Note that there is
also a stim-fixed version released by Verm (but with the same sound issue).

Credits
-------
Original agent:  Mugendai
Stim fix script: (Unknown)
Sound fix:       Emmental

Emmental
https://github.com/chiizujin/edsa
