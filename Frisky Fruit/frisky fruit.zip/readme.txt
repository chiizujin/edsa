Frisky Fruit (1.0)

Shortly after the Shee Ark traversed a strange, glowing asteroid field, this
fruit started to grow in places around the Norn terrarium. It even found its way
into the meso on the Docking Station.

When a Norn eats one they become very friendly indeed...

Notes
-----
- This agent is intended to be injected and removed as required.

Emmental
https://github.com/chiizujin/edsa
